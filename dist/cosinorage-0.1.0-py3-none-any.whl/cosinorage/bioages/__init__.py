# bioages/__init__.py

'''
This module impelements the functionality to compute biological age based on
multiple methods including the novel proposed CosinorAge method.
'''
